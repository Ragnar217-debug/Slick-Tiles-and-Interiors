Source PDFs in this build

BUNDLED:
- cabinets-pricing.pdf
- sanitary-pricing.pdf

SUPPLIED BUT NOT RAW-BUNDLED:
- WK KITCHEN SINK AUG(C)-SLICK PRICELIST-Retail & Projects.pdf
- WK catalogue book-2025 (1).pdf

The storefront includes the sink pricing data (30 products) and the catalogue-derived product imagery available from the bundled pricing sheets. No product image was invented to replace unavailable source artwork.
