WK HOME SHOPPING WEBSITE — V2

Open index.html in a browser.

Included:
- 92 bathroom cabinet / vanity / mirror / shelf products with Retail + Project prices.
- 218 sanitary / faucet / shower / drain / accessory products with Retail + Project prices.
- Original product-photo assets extracted from the supplied cabinet and sanitary PDFs.
- Search, category filters, retail/project price toggle, product details and cart/quote flow.
- Original cabinet and sanitary PDFs are included for catalogue verification.

KITCHEN SINKS:
The supplied kitchen-sink PDF could be read for its 30 product codes, sizes and prices, and those 30 products are included in the website. However, that uploaded PDF could not be copied into the downloadable package by the file service. To enable the sink catalogue-photo preview, place this original file beside index.html:

WK KITCHEN SINK AUG(C)-SLICK PRICELIST-Retail & Projects.pdf

The sink product cards will then open the exact supplied PDF page when you click Details.


IMAGE FIX: Product catalogue photos are embedded directly into index.html as data URLs, so the site does not depend on relative image paths or a web server.
